import { EggLogger } from 'egg';
import { SingletonProto, AccessLevel, Inject } from '@eggjs/tegg';
import { sleep } from '@/module/utils/Sleep';

@SingletonProto({
  // 如果需要在上层使用，需要把 accessLevel 显示声明为 public
  accessLevel: AccessLevel.PUBLIC,
})
export class LoginService {

  @Inject()
  logger: EggLogger;

  @Inject()
  host: string;

  // 登陆接口
  async getLoginUserInfo(name: string, pwd: string): Promise<any> {
    await sleep(1000);
    console.log("name", name);
    console.log("pwd", pwd);
    
    const find = WHITE_LIST.find((i: any) => i.name === name && i.pwd === pwd);
    console.log("find", find);
    
    this.logger.info(JSON.stringify(find));
    if (find) {
        return {
            name: find.name,
            avatar: `http://${this.host}/public${find.avatar}`,
            desc: find.desc,
            sex: find.sex,
            redBookId: find.redBookId,
            location: find.location,
            nickName: find.nickName,
        };
    } else {
        return null;
    }
  }
}

const WHITE_LIST = [
    {
        name: '18751609896',
        nickName: 'FinleyMadoc',
        pwd: '123456',
        sex: 'male',
        redBookId: 118302851,
        avatar: `/avatar/avatar_39.png`,
        location: '地球',
        desc: '地球村人',
    },
    {
        name: '13672967777',
        nickName: 'madoc',
        pwd: '123456',
        sex: 'male',
        redBookId: 118302851,
        avatar: `/avatar/avatar_35.png`,
        location: '地球',
        desc: '地球村人',
    }
];