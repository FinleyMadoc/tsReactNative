const apiConfig = {
    login: {
        url: '/user/login',
        method: 'get'
    },
    homeList: {
        url: '/home/homeList',
        method: 'get'
    }
}

export default apiConfig